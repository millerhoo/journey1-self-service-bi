define({
    "HEATMAPVIZ_DISPLAY_NAME": "HeatMapViz Plugin",
    "HEATMAPVIZ_SHORT_DISPLAY_NAME": "HeatMapViz Plugin",
    "HEATMAPVIZ_CATEGORY":"HeatMapViz Plugin",
    "HEATMAPVIZ_ROW_LABEL":"HeatMapViz Plugin Row",
    "HEATMAPVIZ_ITEM_SIZE":"Item Size",
	"HEATMAPVIZ_ROW":"Latitude&Longitude",
    "HEATMAPVIZ_LABEL":"Labels",
    "HEATMAPVIZ_METRIC":"Metrics",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."

});