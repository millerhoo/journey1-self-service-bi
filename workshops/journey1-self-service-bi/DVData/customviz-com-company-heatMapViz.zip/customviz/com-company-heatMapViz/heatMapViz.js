define(['jquery',
        'obitech-framework/jsx',
        'obitech-report/datavisualization',
        'obitech-reportservices/datamodelshapes',
		'obitech-reportservices/data',
        'obitech-reportservices/events',
        'obitech-appservices/logger',
        'ojL10n!com-company-heatMapViz/nls/messages',
		'obitech-application/gadgets',
		'obitech-report/gadgetdialog',
		'obitech-application/bi-definitions',
        'obitech-application/extendable-ui-definitions',
		'obitech-framework/actioncontext',
		'd3js',
        'obitech-framework/messageformat',
        'css!com-company-heatMapViz/heatMapVizstyles',
		'com-company-heatMapViz/mapsConfig',
 		'com-company-heatMapViz/oraclemapsv2',
		'com-company-heatMapViz/cp/colorpicker',
		'com-company-heatMapViz/cp/eye',
		'com-company-heatMapViz/cp/layout',
		'com-company-heatMapViz/cp/utils'],
 
// use a local oracle maps lib from 12.2.1.2.0 instead of the bundled 12.2.1.1.0 version
// the 2.1.2 version is needed for an updated OSMTileLayer and Dynamic Tile Layer
//		"obitech-map/omaps_api_va", 
//      "obitech-map/va_maps" 
      
        function($,
                 jsx,
                 dataviz,
                 datamodelshapes,
				 data,
                 events,
                 logger,
                 messages,
				 gadgets,
				 gadgetdialog,
				 definitions,
				 euidef,
				 actioncontext,
				 d3) {
   "use strict";

   var MODULE_NAME = 'com-company-heatMapViz/heatMapViz';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   //jsx.assertAllNotNullExceptLastN(arguments, "heatMapViz.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);

   // The version of our Plugin
   HeatMapViz.VERSION = "1.0.0.1";
   
   /**
    * The implementation of the heatMapViz visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-company-heatMapViz/heatMapViz#
    */
   function HeatMapViz(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
      HeatMapViz.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
      
      this.copyRight = null; this.pointsLayer=null; this.heatLayer=null;
	  
	  this.Config ={
	   background: 'Carto Positron', //'OpenStreetMap', 
	   mapkey:'',
	   zoomtotheme:true,
	   repeatbackground:false,
	   pointcolor: '#630303',
	   hmconfig:{}
      };

	  this._saveSettings = function() {
         this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, this.Config);
      };
	  
	  this.loadConfig = function (){
		 var conf = this.getSettings().getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
		 if (conf.background) this.Config.background=conf.background;
         // mapkey will conatin either the Google key or the mapbox access token   
		 if (conf.mapkey) this.Config.mapkey=conf.mapkey;
		 if (conf.zoomtotheme) this.Config.zoomtotheme=conf.zoomtotheme;
		 if (conf.repeatbackground) this.Config.repeatbackground=conf.repeatbackground;
		 if (conf.hmconfig) this.Config.hmconfig=conf.hmconfig;
	  }
      	  
	  this.setPointsLayer = function(o){
			this.pointsLayer=o;
	  };

	  this.setHeatLayer = function(o){
			this.heatLayer=o;
	  };
	  
	  this.setBackground = function (o){
		this.Config.background = o;
		this._saveSettings();		
		};
	 
	  this.setHMConfig = function (o){
		this.Config.hmconfig = o;	
		this._saveSettings();
		};
	  
	  this.setMapKey = function (o){
		this.Config.mapkey = o;	
		this._saveSettings();
		};
		
	  this.setZoomtoTheme = function (o){
		this.Config.zoomtotheme = o;	
		this._saveSettings();
		};
	  
	  this.setRepeatBgd = function (o){
		this.Config.repeatbackground = o;	
		this._saveSettings();
		}; 
   };
   jsx.extend(HeatMapViz, dataviz.DataVisualization);
   
   
   HeatMapViz.prototype._generateData = function(oDataLayout,oLogicalDataModel){
   
   var oDataModel = this.getRootDataModel();
   if(!oDataModel || !oDataLayout){
      return;
   }
   
   var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);
   var nMeasures = aAllMeasures.length;    
   var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
   var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
   var nCols = oDataLayout.getEdgeExtent(datamodelshapes.Physical.COLUMN);
   var nColLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.COLUMN);
   //var aColAddressesInDetail = oLogicalDataModel.getColumnAddressesIn(datamodelshapes.Logical.CATEGORY);

    // Measure labels layer
   var isMeasureLabelsLayer = function (eEdgeType, nLayer) {
      return oDataLayout.getLayerMetadata(eEdgeType, nLayer, data.LayerMetadata.LAYER_ISMEASURE_LABELS);
   };
    
   // Last layer: we get the data values and colors from this layer
   var getLastNonMeasureLayer = function (eEdge) {
      var nLayerCount = oDataLayout.getLayerCount(eEdge);
      for (var i = nLayerCount - 1; i >= 0; i--) {
         if (!isMeasureLabelsLayer(eEdge, i))
            return i;
      }
      return -1;
   };
    
   var nLastEdge = datamodelshapes.Physical.COLUMN; // check column edge first
    
   var nLastLayer = getLastNonMeasureLayer(datamodelshapes.Physical.COLUMN);
   if (nLastLayer < 0) { // if not on column edge look on row edge
      nLastEdge = datamodelshapes.Physical.ROW;
      nLastLayer = getLastNonMeasureLayer(datamodelshapes.Physical.ROW);
   }
    
   var hasCategoryOrColor = function () {
      return nLastLayer >= 0;
   };
   
   var isNumber = function (n) {
   return !isNaN(parseFloat(n)) && isFinite(n);
   };

   //--------------------------------------------------------
   var oData = [];
   var aAllMeasures = this.getRootDataModel().getColumnIDsIn(datamodelshapes.Physical.DATA);
   var lt, lg, sValue;
   oData.metlabel = oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, 0, false);
   
   if(nRows > 0 || nCols > 0){
      var nRow, nCol, nRowLayer, nColLayer;
      for(nRow=0; nRow < Math.max(nRows, 1); nRow++){
		lt = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.ROW, 0, nRow, false));
		lg = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.ROW, 1, nRow, false));		
		
		if (lg && lt && isNumber(lg) && isNumber(lt)) 
		{	
			var metric_val=[], metric_lbl=[], attr_val=[];
			for (nRowLayer=2;nRowLayer<nRowLayerCount;nRowLayer++){
				attr_val.push(oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false));
			}
			
			for(nCol=0; nCol < Math.max(nCols, 1); nCol++){
				var sValue = oDataLayout.getValue(datamodelshapes.Physical.DATA, nRow, nCol);
				var metricLbl = oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, nCol, false);
				metric_val.push(parseFloat(sValue));
				//if (metricLbl=="" && parseFloat(sValue)==1) metric_lbl.push('_'); else 
				metric_lbl.push(metricLbl);
			}
			oData.push({"long":lg, "lat":lt, "attr_val":attr_val, "metric_val":metric_val, "metric_lbl":metric_lbl});
		}
      }
	}
	//--------------------------------------------------------
    if (oData.length>0)
		return oData; 
	else
		return null;
   };
   
   
   /**
    * Called whenever new data is ready and this visualization needs to update.
    * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
    */
   HeatMapViz.prototype.render = function(oTransientRenderingContext) {
      // Note: all events will be received after initialize and start complete.  We may get other events
      // such as 'resize' before the render, i.e. this might not be the first event.

      // Retrieve the data object for this visualization
      var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
	  var oLogicalDataModel = oTransientRenderingContext.get(dataviz.DataContextProperty.LOGICAL_DATA_MODEL);

      // Determine the number of records available for rendering on ROW
      // Because we specified that Category should be placed on ROW in the data model handler,
      // this returns the number of rows for the data in Category.
      //var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
	  var oData= this._generateData(oDataLayout,oLogicalDataModel);	  
	  if (!oData) return;
	  
	  var elContainer = this.getContainerElem();
	  $(elContainer).html('');
	  var map = new OM.Map(elContainer);
	  this.loadConfig();
	  var modalHTML = '<div id="myModal" class="modal"> \
		<div class="modal-content"> \
		<span class="close" id="closeBtn">&times;</span><br/> \
		<table style="cell-padding:5px;cell-spacing:2px;width:250px"> \
		<tr><td colspan="2">Heatmap using: <input type="radio" name="radioBtnName" id="htype_density"> Point Density  \
		<input type="radio" name="radioBtnName" id="htype_metric" checked> Metric</td></tr> \
		<tr><td colspan="2">Metric Min: <input type="text" value="" id="metMin" style="width: 60px;">\
		&nbsp;&nbsp;Max: <input type="text" value="" id="metMax" style="width: 60px;"></td></tr> \
		<tr><td colspan=2><hr style="border-top: 1px dashed #8c8b8b;"></td></tr> \
		<tr><td>Radius:</td><td><input type="text" value="25" id="radius"></td></tr> \
		<tr><td>Radius Unit:</td><td> \
		<select id="unit"><option value="pixel">Pixel</option><option value="mile">Mile</option><option value="kilometer">KM</option></select> \
		</td></tr> \
		<tr><td>Sample Factor:</td><td><input type="text" value="4" id="factor"></td></tr> \
		<tr><td colspan="2">Color Stops:</td></tr> \
		<tr><td colspan="2"> \
		<table id="color"><tr> \
		<td><div class="colorsel" style="background-color:#C6DBEF" id="color1"/></td> \
		<td><div class="colorsel" style="background-color:#008fff" id="color2"/></td> \
		<td><div class="colorsel" style="background-color:#00d5ff" id="color3"/></td> \
		<td><div class="colorsel" style="background-color:#00ff7f" id="color4"/></td> \
		<td><div class="colorsel" style="background-color:#ffff00" id="color5"/></td> \
		<td><div class="colorsel" style="background-color:#ffab00" id="color6"/></td> \
		<td><div class="colorsel" style="background-color:#ff2b00" id="color7"/></td> \
		<td><div class="colorsel" style="background-color:#A50F15" id="color8"/></td> \
		</tr></table> \
		</td></tr> \
		<tr><td>Global Opacity:</td><td><input type="text" value="0.65" id="opacity"></td></tr> \
		<tr><td colspan="2"><button id="applybtn" class="applybtn">Apply</button></td><tr> \
		</table> \
		</div> </div>';
	  
	    function S4() {
			return (((1+Math.random())*0x10000)|0).toString(16).substring(1); 
		}
		var uName = 'nm_'+(S4() + S4() + "-" + S4()).toLowerCase();
		modalHTML = modalHTML.replace(/radioBtnName/g,uName);
		
	   $(elContainer).append(modalHTML);
	  
	  if (this.Config.hmconfig.lengthUnit) {
		var radioBtnDensity = $(elContainer).find('#htype_density')[0];
		if (this.Config.hmconfig.type=='density') radioBtnDensity.checked=true;
	    
		$(elContainer).find("#radius")[0].value = this.Config.hmconfig.spotlightRadius ;
		$(elContainer).find("#unit")[0].value = this.Config.hmconfig.lengthUnit ;
		$(elContainer).find("#factor")[0].value = this.Config.hmconfig.sampleFactor ;
		$(elContainer).find("#opacity")[0].value = this.Config.hmconfig.opacity ;
		$(elContainer).find("#metMin")[0].value = this.Config.hmconfig.minValue ;
		$(elContainer).find("#metMax")[0].value = this.Config.hmconfig.maxValue ;
		for(var i=1; i<=8; i++)
		  {
			var e=$(elContainer).find("#color"+i)[0];
			$(e).css("background-color" , this.Config.hmconfig.colorStops[i-1]);
		  }
	  }
	  
	$("#color1, #color2, #color3, #color4, #color5, #color6, #color7, #color8").ColorPicker({
			color: '#000000',
			onShow: function (colpkr) {
					console.log(colpkr);
				$(colpkr).fadeIn(500);
				return false;
			},
			onHide: function (colpkr) {
				$(colpkr).fadeOut(500);
				return false;
			},
			onSubmit: function(hsb, hex, rgb, el) {
				$(el).css("background-color", '#'+hex);
					$(el).ColorPickerHide();
			}
		})
	
	  this.renderMap(oData, map);
	  this._setIsRendered(true);
   }

	HeatMapViz.prototype.renderMap = function(darray, map) {
      var elContainer = this.getContainerElem();
	  //var map = new OM.Map(elContainer);
	  var tilelayer;
      
      var toolTipCustomizer = function(aFeature){
          var theAttributes;
          var aNames, aValues, aHead=[];
          // create the object to return.
          // this should probably be just fetched from the data model itself
          // i.e. the Features should not be created with attributes which are just a copy of 
          // information also contained in the data model.
          // The Features should be created with IDs which are indexes into the darray
          // and use darray to create the tooltip info
          
          // for now though we'll use the brute force approach because of auto-clustering
          if(aFeature.hasAttributes())
          { 
              theAttributes = aFeature.getAttributes();
              aNames = Object.keys(theAttributes);
			  var idx = aNames.indexOf('_TITLE_');
			  if(idx != -1) {
			  	aNames.splice(idx, 1);
			  }
			  aHead = theAttributes['_TITLE_'];
              aValues=[];
              for(var i=0; i<aNames.length;i++)
              {
                  if (aNames[i]!='_TITLE_') 
					  aValues.push(theAttributes[aNames[i]]);
              }
          }
          else if(aFeature.isCluster()){
              var numInCluster = aFeature.cluster.featureArray.length;
              aNames = ['Count'];
              aValues = [numInCluster];
              //console.log('Cluster with ' + numInCluster + ' features');
          }

          return {
              titlesArray: aHead,
              headersArray: aNames.length > 0 ? aNames : ['Undefined'],
              contentsArray: aValues.length > 0 ? aValues : [0]              
          };
      };
      
	  	  if (this.Config.background == 'OpenStreetMap')
      {
		tilelayer = new OM.layer.OSMTileLayer("osm.maps");
        var copyRightOSM = new OM.control.CopyRight(
            {anchorPosition:6,
            textValue:'&copy; <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
            fontSize:10,fontFamily:'Helvetica Neue,Arial',fontColor:'black'});
        // remove any existing copyRight and add new one 
        map.removeMapDecoration(this.copyRight);
        map.addMapDecoration(copyRightOSM);
        this.copyRight = copyRightOSM;
      }
	  else if (this.Config.background == 'Google Maps')
	  {
		  conf_google_maps.key = this.Config.mapkey;
		  tilelayer = new OM.layer.GoogleTileLayer("google.maps", conf_google_maps);
          map.removeMapDecoration(this.copyRight);
	  }
	  else if (this.Config.background == 'Mapbox Light')
	  {
        var copyRightMapBox = new OM.control.CopyRight(
            {anchorPosition:6,
            textValue:
            '<a href="https://www.mapbox.com/about/maps/" target="_blank">&copy; Mapbox</a> <a href="http://www.openstreetmap.org/about/" target="_blank">&copy; OpenStreetMap</a>', 
            fontSize:10,fontFamily:'Helvetica Neue,Arial',fontColor:'black'}); 

		  conf_mapbox_maps.key = this.Config.mapkey;            
          if(conf_mapbox_maps.key == null || conf_mapbox_maps.key == "") 
          {
              console.log('Enter an access key. See mapbox.com/developers for details.');
          }              
          conf_mapbox_maps.tileServerArray=["http://api.mapbox.com/v4/mapbox.light"];
		  tilelayer = new OM.layer.OSMTileLayer("mapbox.light", conf_mapbox_maps.tileServerArray, ".png", {"access_token":conf_mapbox_maps.key});
        // remove copyRight and add new one 
        map.removeMapDecoration(this.copyRight);
        map.addMapDecoration(copyRightMapBox);
        this.copyRight = copyRightMapBox;
      }
	  else if (this.Config.background == 'Carto Positron')
	  {
        var copyRightCarto = new OM.control.CopyRight(
            {anchorPosition:6,
            textValue:'&copy; <a href="http://cartodb.com/attributions" target="_blank">Carto</a> free basemaps <a href="https://carto.com/legal" target="_blank">terms</a>. &copy; <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors', fontSize:10,fontFamily:'Helvetica Neue,Arial',fontColor:'black'});    
        
		  var conf_carto_maps={};
          conf_carto_maps.tileServerArray=[
          "http://a.basemaps.cartocdn.com/light_all", 
          "http://b.basemaps.cartocdn.com/light_all", 
          "http://c.basemaps.cartocdn.com/light_all", 
          "http://d.basemaps.cartocdn.com/light_all"];	

		  tilelayer = new OM.layer.OSMTileLayer("carto.light", conf_carto_maps.tileServerArray, ".png");
        // remove copyRight and add new one 
        map.removeMapDecoration(this.copyRight);
        map.addMapDecoration(copyRightCarto);
        this.copyRight = copyRightCarto;
      }
	  else if (this.Config.background == 'Carto Dark')
	  {
        var copyRightCarto = new OM.control.CopyRight(
        {anchorPosition:6,
        textValue:'&copy; <a href="http://cartodb.com/attributions" target="_blank">Carto</a> free basemaps <a href="https://carto.com/legal" target="_blank">terms</a>. &copy; <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors', fontSize:10,fontFamily:'Helvetica Neue,Arial',fontColor:'black'});    
        
		  var conf_carto_maps={};
          conf_carto_maps.tileServerArray=[
          "http://a.basemaps.cartocdn.com/dark_all", "http://b.basemaps.cartocdn.com/dark_all", 
          "http://c.basemaps.cartocdn.com/dark_all", "http://d.basemaps.cartocdn.com/dark_all"];	
          
		  tilelayer = new OM.layer.OSMTileLayer("carto.dark", conf_carto_maps.tileServerArray, ".png");
        // remove copyRight and add new one 
        map.removeMapDecoration(this.copyRight);
        map.addMapDecoration(copyRightCarto);
        this.copyRight = copyRightCarto;
      }      
	  else
      {
		tilelayer = new OM.layer.ElocationTileLayer("oracle.maps");
        map.removeMapDecoration(this.copyRight);
      }
		
	  map.addLayer(tilelayer); 
  
	  this.pointsLayer = new OM.layer.VectorLayer("pointsLayer", { def:{	type:OM.layer.VectorLayer.TYPE_LOCAL }  });   
	  this.heatLayer = new OM.layer.VectorLayer("heatLayer", { def:{	type:OM.layer.VectorLayer.TYPE_LOCAL }  }); 
	  var pointsLayer = this.pointsLayer;	  
	  var heatLayer = this.heatLayer;
	  var features = [], densityMet =[];	  
	  
	  //{"long":lg, "lat":lt, "attr_val":attr_val, "metric_val":metric_val, "metric_lbl":metric_lbl}
	  for (i=0;i<darray.length; i++){
	  		var fid = i;
			var pt = darray[i];
	  		var mpoint = new OM.geometry.Point(pt.long, pt.lat,8307);
	  		var f_attr = {attributes :{}};
			
			f_attr.attributes['_TITLE_']= pt.attr_val;
			for (var k=0;k<pt.metric_val.length;k++){
				f_attr.attributes[pt.metric_lbl[k]]=pt.metric_val[k];
			}
			features.push(new OM.Feature(fid,mpoint,f_attr));   		
			
			if (pt.metric_val.length>0 && pt.metric_lbl[0]!="") densityMet.push(pt.metric_val[0]);
	  	}
	  pointsLayer.addFeatures(features);
	  heatLayer.addFeatures(features);
	  
	  var pt = darray[0];
	  this.metriclabel=pt.metric_lbl[0];

	  if (densityMet.length>0){
		  densityMet.sort(function(a, b){return a - b});
		  var densityLmt1 = d3.quantile(densityMet,0.25);
		  var densityLmt2 = d3.quantile(densityMet,0.75);
		  $(elContainer).find('#metMin')[0].value= densityLmt1;
	      $(elContainer).find('#metMax')[0].value= densityLmt2;
		  this.setupHMSettings('metric');
		  //heatLayer.setRenderingStyle(this.getStyleConfig(),[this.metriclabel]);
	  } else {
		  $(elContainer).find('#metMin')[0].value= 0;
	      $(elContainer).find('#metMax')[0].value= 0;
		  this.setupHMSettings('density');
		  //heatLayer.setRenderingStyle(this.getStyleConfig());
	  }	 
	  
	  this.renderHeatMap(this);
	   
      var circleMarker = new OM.style.Marker({
	    vectorDef : [{
	  		shape: { type:"circle", cx:3, cy:3, width:6, height:6 }, 
	  		style: { fill: conf_marker.fill }
	  	}],
	    width: 6,
	    height:6
	  });
	  pointsLayer.setRenderingStyle(circleMarker);
	  
	  pointsLayer.setBringToTopOnMouseOver(true);
      // disable info-windows and set a tooltip customizer
      // the tooltip customizer should just return the Object or text to be displayed in the tooltip
      pointsLayer.enableInfoWindow(false);
      // set Feature Hiver to true to enable the hover events
      pointsLayer.enableFeatureHover(true);
      pointsLayer.setToolTipCustomizer(toolTipCustomizer);
	  if (this.Config.zoomtotheme)	  
		  pointsLayer.zoomToTheme();
	  
	  map.addLayer(heatLayer);  
	  map.addLayer(pointsLayer);
	  

	  
      if (!this.Config.zoomtotheme)	  map.setMapZoomLevel(3) ;
	  if (this.Config.repeatbackground) map.enableMapWraparound(true);

	  var center = new OM.geometry.Point(10,48,8307); 
	  map.setMapCenter(center);
  
      // show only the +/- zoom buttons. i.e. {style:3}
	  var navigationPanelBar = new OM.control.NavigationPanelBar({style:3});
	  map.addMapDecoration(navigationPanelBar);
	  
	  var h= $(elContainer).height() - 30;

	  //Add a gear icon on the left bottom corner
	  var decorHTML1 = '<div id="hmSettings" class="gearicon" /> ';
	  var decorHTML2 = '<div id="pointsSwitch" class="pointsOn" />';	  
  	  var modalCtl1 = new OM.control.MapDecoration(decorHTML1,{offsetX:12,offsetY:h, contentStyle:{"border-width":"0px", "padding":"2px","backgroundColor":"#efefef","cursor": "pointer"}});
	  var modalCtl2 = new OM.control.MapDecoration(decorHTML2,{offsetX:12,offsetY:h-25, contentStyle:{"border-width":"0px", "padding":"2px","backgroundColor":"#efefef","cursor": "pointer"}});
	  map.addMapDecoration(modalCtl1);
	  map.addMapDecoration(modalCtl2);
	  map.init();
	  
	  var btn = $(elContainer).find('#hmSettings')[0]; 
	  var modal = $(elContainer).find('#myModal')[0];
	  btn.onclick = function() {  modal.style.display = "block";  }	  
	  this.showPoints();
    };
	
	HeatMapViz.prototype.showPoints = function(){
	  var elContainer = this.getContainerElem();
	  var ptSwitch = $(elContainer).find('#pointsSwitch')[0];
	  var ptLayer = this.pointsLayer;
      
	  ptSwitch.onclick = function() {
	  	if (ptSwitch.className == "pointsOn") {
			ptSwitch.className = "pointsOff";
			ptLayer.setVisible(false);
		} else {
			ptSwitch.className = "pointsOn";
			ptLayer.setVisible(true);
		}
	  }
	};
	
	HeatMapViz.prototype.setupHMSettings = function(type){
	  var elContainer = this.getContainerElem();
	  
	  var radioBtnDensity = $(elContainer).find('#htype_density')[0];
	  var modal = $(elContainer).find('#myModal')[0];
	  var span = $(elContainer).find('#closeBtn')[0];
	  var applybtn = $(elContainer).find('#applybtn')[0];
	  var renderHM = this.renderHeatMap;
	  var self = this;
	  
	  if (type!="metric") radioBtnDensity.checked=true;

	  // When the user clicks on <span> (x), close the modal
	  span.onclick = function() {
	  	modal.style.display = "none";
	  }
	  
	  modal.onclick = function(event){
		  if (event.target == modal) {
	  		modal.style.display = "none";
	  	}
	  }
	  
	  applybtn.onclick = function() {
	  	renderHM(self);
		modal.style.display = "none";
	  }
	};
	
	HeatMapViz.prototype.renderHeatMap = function(self){
	  var elContainer = self.getContainerElem();
	  var radioBtnDensity = $(elContainer).find('#htype_density')[0];

	  if (radioBtnDensity.checked==true) {
		 self.heatLayer.setRenderingStyle(self.getStyleConfig(),[]);
	  } else {
		 self.heatLayer.setRenderingStyle(self.getStyleConfig(),[self.metriclabel]);  
	  }
	};
	
	HeatMapViz.prototype.getStyleConfig = function()
	{
	  var elContainer = this.getContainerElem();
	  var radioBtnDensity = $(elContainer).find('#htype_density')[0];
	  var type = 'metric';
	  if (radioBtnDensity.checked==true) type='density';
	  //var colors = ["#C6DBEF","#6BAED6","#008fff","#00abff","#00d5ff","#00ffff","#00ff7f","#00ff00","#7fff00","#ffff00","#ffd500","#ffab00","#ff7f00","#ff5600","#ff2b00", "#ff0000", "#A50F15"];
	  var colors = [];
	  for(var i=1; i<=8; i++)
	  {
		var e=$(elContainer).find("#color"+i)[0];
		colors.push($(e).css("background-color"))
	  }
	  var radius = parseFloat($(elContainer).find("#radius")[0].value);
	  var unit = $(elContainer).find("#unit")[0].value;
	  var factor = parseInt($(elContainer).find("#factor")[0].value);
	  var opacity = parseFloat($(elContainer).find("#opacity")[0].value);
	  var config = {
		spotlightRadius:radius,
		lengthUnit:unit,
		colorStops: colors,
		opacity:opacity,                   
		sampleFactor: factor
	  }
	  if (type=="metric")
	  {
		var min = parseFloat($(elContainer).find("#metMin")[0].value);
		var max = parseFloat($(elContainer).find("#metMax")[0].value);
		if (isNaN(min)) 
		{
		  config.minValue = 0;
		  $(min).value=0;
		}
		else
		  config.minValue = min;
		if (isNaN(max)) 
		{
		  config.maxValue = 0;
		  $(max).value=0;
		}
		else
		  config.maxValue = max;
	  }
	  
	  var hmconfig =config;
	  hmconfig.type=type;
	  this.setHMConfig(hmconfig);
	  var heatStyle = new OM.style.HeatMap(config);
	  return heatStyle;
	};

	HeatMapViz.prototype._addVizSpecificPropsDialog = function(oTabbedPanelsGadgetInfo){
		this.doAddVizSpecificPropsDialog(this, oTabbedPanelsGadgetInfo);
		HeatMapViz.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);
	};

	HeatMapViz.prototype.doAddVizSpecificPropsDialog = function (oTransientRenderingContext, oTabbedPanelsGadgetInfo) {
		  jsx.assertObject(oTransientRenderingContext, "oTransientRenderingContext");
		  jsx.assertInstanceOf(oTabbedPanelsGadgetInfo, gadgets.TabbedPanelsGadgetInfo, "oTabbedPanelsGadgetInfo", "obitech-application/gadgets.TabbedPanelsGadgetInfo");

		  var options = this.getViewConfig() || {};
		  this._fillDefaultOptions(options, null);

		  var generalPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);

		  var background = [];
		  background.push(new gadgets.OptionInfo('OpenStreetMap','OpenStreetMap'));
		  background.push(new gadgets.OptionInfo('Oracle Maps','Oracle Maps'));
		  background.push(new gadgets.OptionInfo('Google Maps','Google Maps'));
		  background.push(new gadgets.OptionInfo('Mapbox Light','Mapbox Light'));
          //background.push(new gadgets.OptionInfo('Carto Dark','Carto Dark'));
          background.push(new gadgets.OptionInfo('Carto Positron','Carto Positron'));          
          
		  var oBackgroundGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.background);
		  var oBackgroundGadgetInfo = new gadgets.TextSwitcherGadgetInfo("backgroundGadget", 'Background Map', 'Background Map', oBackgroundGVP, 90, false, background);
		  generalPanel.addChild(oBackgroundGadgetInfo);

		  var oGadgetFactory = this.getGadgetFactory();
		  var oMapKey = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.mapkey);
          var oMapKeyGadgetInfo = oGadgetFactory.createGadgetInfo("mapKeyGadget", 'Map Key (Google|MapBox)', 'Map Key (Google|MapBox)', oMapKey,91);
          generalPanel.addChild(oMapKeyGadgetInfo);
                
		  var oZoomControlProps = new gadgets.CheckboxGadgetValueProperties(euidef.GadgetTypeIDs.TEXT_TOGGLE, "zoomToThemecontrol", this.Config.zoomtotheme);
          var oZoomControlCheckboxInfo = oGadgetFactory.createGadgetInfo("zoomToThemecontrol","Zoom to Points", "Zoom to Points", oZoomControlProps,92);
          generalPanel.addChild(oZoomControlCheckboxInfo);
		  
		  /*var oRepeatBgdProps = new gadgets.CheckboxGadgetValueProperties(euidef.GadgetTypeIDs.TEXT_TOGGLE, "repeatMapcontrol", this.Config.repeatbackground);
          var oRepeatBgdCheckboxInfo = oGadgetFactory.createGadgetInfo("repeatMapcontrol","Repeat Background", "Repeat Background", oRepeatBgdProps,40);
          generalPanel.addChild(oRepeatBgdCheckboxInfo);

		  var oImgURL = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.imageurl);
          var oImgURLGadgetInfo = oGadgetFactory.createGadgetInfo("imgURLGadget", 'Image Marker URL', 'Image Marker URL', oImgURL);
          generalPanel.addChild(oImgURLGadgetInfo);		  */

		  if (HeatMapViz.superClass.doAddVizSpecificPropsDialog)
			HeatMapViz.superClass.doAddVizSpecificPropsDialog.apply(this, arguments);
	};


	HeatMapViz.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext){
	   var updateSettings = HeatMapViz.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);      
		  if (updateSettings) {
			 return updateSettings; // super handled it
		  }

	   // Allow the super class an attempt to handle the changes
	   var conf = oViewSettings.getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
		  
		if (sGadgetID === "backgroundGadget")
		  {
			 if (jsx.isNull(conf.background))
			 {
				conf.background = {};
			 }
			 this.setBackground(oPropChange.value);
			 updateSettings = true;
		  }
		 
		 if (sGadgetID === "imgURLGadget")
		  {
			 if (jsx.isNull(conf.imageurl))
			 {
				conf.imageurl = '';
			 }
			 this.setImageURL(oPropChange.value);
			 updateSettings = true;
		  }
		  
		 if (sGadgetID === "mapKeyGadget")
		  {
			 if (jsx.isNull(conf.mapkey))
			 {
				conf.mapkey = '';
			 }
			 this.setMapKey(oPropChange.value);
			 updateSettings = true;
		  }
		  
		  if (sGadgetID === "zoomToThemecontrol")
		  {
			 if (jsx.isNull(conf.zoomtotheme))
			 {
				conf.zoomtotheme = false;
			 }
			 this.setZoomtoTheme(oPropChange.checked);
			 updateSettings = true;
		  }
		  
		  if (sGadgetID === "repeatMapcontrol")
		  {
			 if (jsx.isNull(conf.repeatbackground))
			 {
				conf.repeatbackground = false;
			 }
			 this.setRepeatBgd(oPropChange.checked);
			 updateSettings = true;
		  }
		  return updateSettings;
	};
	
	
	HeatMapViz.prototype.resizeVisualization = function(oVizDimensions, oTransientVizContext){
	   var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
	   this.render(oTransientRenderingContext);
	};
	
   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-company-heatMapViz/heatMapViz.HeatMapViz}
    * @memberof module:com-company-heatMapViz/heatMapViz
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new HeatMapViz(sID, sDisplayName, sOrigin, HeatMapViz.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});