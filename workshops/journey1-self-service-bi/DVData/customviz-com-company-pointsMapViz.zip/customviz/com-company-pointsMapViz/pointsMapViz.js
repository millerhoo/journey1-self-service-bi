define(['jquery',
        'obitech-framework/jsx',
        'obitech-report/datavisualization',
        'obitech-reportservices/datamodelshapes',
		'obitech-reportservices/data',
        'obitech-reportservices/events',
        'obitech-appservices/logger',
        'ojL10n!com-company-pointsMapViz/nls/messages',
		'obitech-application/gadgets',
		'obitech-report/gadgetdialog',
		'obitech-application/bi-definitions',
        'obitech-application/extendable-ui-definitions',
		'obitech-framework/actioncontext',
        'obitech-framework/messageformat',
        'css!com-company-pointsMapViz/pointsMapVizstyles',
		'com-company-pointsMapViz/mapsConfig',
 		'com-company-pointsMapViz/oraclemapsv2'],
 
// use a local oracle maps lib from 12.2.1.2.0 instead of the bundled 12.2.1.1.0 version
// the 2.1.2 version is needed for an updated OSMTileLayer and Dynamic Tile Layer
//		"obitech-map/omaps_api_va", 
//      "obitech-map/va_maps" 
      
        function($,
                 jsx,
                 dataviz,
                 datamodelshapes,
				 data,
                 events,
                 logger,
                 messages,
				 gadgets,
				 gadgetdialog,
				 definitions,
				 euidef,
				 actioncontext) {
   "use strict";

   var MODULE_NAME = 'com-company-pointsMapViz/pointsMapViz';

   //Param validation to detect cyclical dependencies (ignore modules not used in resource arguments)
   //jsx.assertAllNotNullExceptLastN(arguments, "pointsMapViz.js arguments", 2);

   var _logger = new logger.Logger(MODULE_NAME);

   // The version of our Plugin
   PointsMapViz.VERSION = "1.0.0.1";
   
   /**
    * The implementation of the pointsMapViz visualization.
    * 
    * @constructor
    * @param {string} sID
    * @param {string} sDisplayName
    * @param {string} sOrigin
    * @param {string} sVersion
    * @extends {module:obitech-report/visualization.Visualization}
    * @memberof module:com-company-pointsMapViz/pointsMapViz#
    */
   function PointsMapViz(sID, sDisplayName, sOrigin, sVersion) {
      // Argument validation done by base class
      PointsMapViz.baseConstructor.call(this, sID, sDisplayName, sOrigin, sVersion);
      
      this.copyRight = null;
	  
	  this.Config ={
	   background: 'Carto Positron', //'OpenStreetMap', 
	   imageurl:'',
	   mapkey:'',
	   zoomtotheme:false,
	   repeatbackground:false
      };

	  this._saveSettings = function() {
         this.getSettings().setViewConfigJSON(dataviz.SettingsNS.CHART, this.Config);
      };
	  
	  this.loadConfig = function (){
		 var conf = this.getSettings().getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
		 if (conf.background) this.Config.background=conf.background;
		 if (conf.imageurl) this.Config.imageurl=conf.imageurl;
         // mapkey will conatin either the Google key or the mapbox access token   
		 if (conf.mapkey) this.Config.mapkey=conf.mapkey;
		 if (conf.zoomtotheme) this.Config.zoomtotheme=conf.zoomtotheme;
		 if (conf.repeatbackground) this.Config.repeatbackground=conf.repeatbackground;
	  }
      	  
	  this.setBackground = function (o){
		this.Config.background = o;
		this._saveSettings();		
		};
	 
	  this.setImageURL = function (o){
		this.Config.imageurl = o;	
		this._saveSettings();
		};
	  
	  this.setMapKey = function (o){
		this.Config.mapkey = o;	
		this._saveSettings();
		};
		
	  this.setZoomtoTheme = function (o){
		this.Config.zoomtotheme = o;	
		this._saveSettings();
		};
	  
	  this.setRepeatBgd = function (o){
		this.Config.repeatbackground = o;	
		this._saveSettings();
		};  	 
   };
   jsx.extend(PointsMapViz, dataviz.DataVisualization);
   
   
   PointsMapViz.prototype._generateData = function(oDataLayout,oLogicalDataModel){
   
   var oDataModel = this.getRootDataModel();
   if(!oDataModel || !oDataLayout){
      return;
   }
   
   var aAllMeasures = oDataModel.getColumnIDsIn(datamodelshapes.Physical.DATA);
   var nMeasures = aAllMeasures.length;    
   var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
   var nRowLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.ROW);
   var nCols = oDataLayout.getEdgeExtent(datamodelshapes.Physical.COLUMN);
   var nColLayerCount = oDataLayout.getLayerCount(datamodelshapes.Physical.COLUMN);
   //var aColAddressesInDetail = oLogicalDataModel.getColumnAddressesIn(datamodelshapes.Logical.CATEGORY);

    // Measure labels layer
   var isMeasureLabelsLayer = function (eEdgeType, nLayer) {
      return oDataLayout.getLayerMetadata(eEdgeType, nLayer, data.LayerMetadata.LAYER_ISMEASURE_LABELS);
   };
    
   // Last layer: we get the data values and colors from this layer
   var getLastNonMeasureLayer = function (eEdge) {
      var nLayerCount = oDataLayout.getLayerCount(eEdge);
      for (var i = nLayerCount - 1; i >= 0; i--) {
         if (!isMeasureLabelsLayer(eEdge, i))
            return i;
      }
      return -1;
   };
    
   var nLastEdge = datamodelshapes.Physical.COLUMN; // check column edge first
    
   var nLastLayer = getLastNonMeasureLayer(datamodelshapes.Physical.COLUMN);
   if (nLastLayer < 0) { // if not on column edge look on row edge
      nLastEdge = datamodelshapes.Physical.ROW;
      nLastLayer = getLastNonMeasureLayer(datamodelshapes.Physical.ROW);
   }
    
   var hasCategoryOrColor = function () {
      return nLastLayer >= 0;
   };
   
   var isNumber = function (n) {
   return !isNaN(parseFloat(n)) && isFinite(n);
   };

   //--------------------------------------------------------
   var oData = [];
   var aAllMeasures = this.getRootDataModel().getColumnIDsIn(datamodelshapes.Physical.DATA);
   var lt, lg, sValue;
   oData.metlabel = oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, 0, false);
   
   if(nRows > 0 || nCols > 0){
      var nRow, nCol, nRowLayer, nColLayer;
      for(nRow=0; nRow < Math.max(nRows, 1); nRow++){
		lt = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.ROW, 0, nRow, false));
		lg = parseFloat(oDataLayout.getValue(datamodelshapes.Physical.ROW, 1, nRow, false));		
		
		if (lg && lt && isNumber(lg) && isNumber(lt)) 
		{	
			var metric_val=[], metric_lbl=[], attr_val=[];
			for (nRowLayer=2;nRowLayer<nRowLayerCount;nRowLayer++){
				attr_val.push(oDataLayout.getValue(datamodelshapes.Physical.ROW, nRowLayer, nRow, false));
			}
			
			for(nCol=0; nCol < Math.max(nCols, 1); nCol++){
				var sValue = oDataLayout.getValue(datamodelshapes.Physical.DATA, nRow, nCol);
				var metricLbl = oDataLayout.getValue(datamodelshapes.Physical.COLUMN, 0, nCol, false);
				metric_val.push(parseFloat(sValue));
				//if (metricLbl=="" && parseFloat(sValue)==1) metric_lbl.push('_'); else 
				metric_lbl.push(metricLbl);
			}
			oData.push({"long":lg, "lat":lt, "attr_val":attr_val, "metric_val":metric_val, "metric_lbl":metric_lbl});
		}
      }
	}
	//--------------------------------------------------------
    if (oData.length>0)
		return oData; 
	else
		return null;
   }
   
   /**
    * Called whenever new data is ready and this visualization needs to update.
    * @param {module:obitech-renderingcontext/renderingcontext.RenderingContext} oTransientRenderingContext
    */
   PointsMapViz.prototype.render = function(oTransientRenderingContext) {
      // Note: all events will be received after initialize and start complete.  We may get other events
      // such as 'resize' before the render, i.e. this might not be the first event.

      // Retrieve the data object for this visualization
      var oDataLayout = oTransientRenderingContext.get(dataviz.DataContextProperty.DATA_LAYOUT);
	  var oLogicalDataModel = oTransientRenderingContext.get(dataviz.DataContextProperty.LOGICAL_DATA_MODEL);

      // Determine the number of records available for rendering on ROW
      // Because we specified that Category should be placed on ROW in the data model handler,
      // this returns the number of rows for the data in Category.
      //var nRows = oDataLayout.getEdgeExtent(datamodelshapes.Physical.ROW);
	  var oData= this._generateData(oDataLayout,oLogicalDataModel);	  
	  if (!oData) return;
	  var darray=oData;

	  // Retrieve the root container for our visualization.  This is provided by the framework.  It may not be deleted
      // but may be used to render.
      var elContainer = this.getContainerElem();
	  var map = new OM.Map(elContainer);
	  var tilelayer;
      
      var toolTipCustomizer = function(aFeature){
          var theAttributes;
          var aNames, aValues, aHead=[];
          // create the object to return.
          // this should probably be just fetched from the data model itself
          // i.e. the Features should not be created with attributes which are just a copy of 
          // information also contained in the data model.
          // The Features should be created with IDs which are indexes into the darray
          // and use darray to create the tooltip info
          
          // for now though we'll use the brute force approach because of auto-clustering
          if(aFeature.hasAttributes())
          { 
              theAttributes = aFeature.getAttributes();
              aNames = Object.keys(theAttributes);
			  var idx = aNames.indexOf('_TITLE_');
			  if(idx != -1) {
			  	aNames.splice(idx, 1);
			  }
			  aHead = theAttributes['_TITLE_'];
              aValues=[];
              for(var i=0; i<aNames.length;i++)
              {
                  if (aNames[i]!='_TITLE_') 
					  aValues.push(theAttributes[aNames[i]]);
              }
          }
          else if(aFeature.isCluster()){
              var numInCluster = aFeature.cluster.featureArray.length;
              aNames = ['Count'];
              aValues = [numInCluster];
              //console.log('Cluster with ' + numInCluster + ' features');
          }

          return {
              titlesArray: aHead,
              headersArray: aNames.length > 0 ? aNames : ['Undefined'],
              contentsArray: aValues.length > 0 ? aValues : [0]              
          };
      };
      
	  this.loadConfig();
	  if (this.Config.background == 'OpenStreetMap')
      {
		tilelayer = new OM.layer.OSMTileLayer("osm.maps");
        var copyRightOSM = new OM.control.CopyRight(
            {anchorPosition:6,
            textValue:'&copy; <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
            fontSize:10,fontFamily:'Helvetica Neue,Arial',fontColor:'black'});
        // remove any existing copyRight and add new one 
        map.removeMapDecoration(this.copyRight);
        map.addMapDecoration(copyRightOSM);
        this.copyRight = copyRightOSM;
      }
	  else if (this.Config.background == 'Google Maps')
	  {
		  conf_google_maps.key = this.Config.mapkey;
		  tilelayer = new OM.layer.GoogleTileLayer("google.maps", conf_google_maps);
          map.removeMapDecoration(this.copyRight);
	  }
	  else if (this.Config.background == 'Mapbox Light')
	  {
        var copyRightMapBox = new OM.control.CopyRight(
            {anchorPosition:6,
            textValue:
            '<a href="https://www.mapbox.com/about/maps/" target="_blank">&copy; Mapbox</a> <a href="http://www.openstreetmap.org/about/" target="_blank">&copy; OpenStreetMap</a>', 
            fontSize:10,fontFamily:'Helvetica Neue,Arial',fontColor:'black'}); 

		  conf_mapbox_maps.key = this.Config.mapkey;            
          if(conf_mapbox_maps.key == null || conf_mapbox_maps.key == "") 
          {
              console.log('Enter an access key. See mapbox.com/developers for details.');
          }              
          conf_mapbox_maps.tileServerArray=["http://api.mapbox.com/v4/mapbox.light"];
		  tilelayer = new OM.layer.OSMTileLayer("mapbox.light", conf_mapbox_maps.tileServerArray, ".png", {"access_token":conf_mapbox_maps.key});
        // remove copyRight and add new one 
        map.removeMapDecoration(this.copyRight);
        map.addMapDecoration(copyRightMapBox);
        this.copyRight = copyRightMapBox;
      }
	  else if (this.Config.background == 'Carto Positron')
	  {
        var copyRightCarto = new OM.control.CopyRight(
            {anchorPosition:6,
            textValue:'&copy; <a href="http://cartodb.com/attributions" target="_blank">Carto</a> free basemaps <a href="https://carto.com/legal" target="_blank">terms</a>. &copy; <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors', fontSize:10,fontFamily:'Helvetica Neue,Arial',fontColor:'black'});    
        
		  var conf_carto_maps={};
          conf_carto_maps.tileServerArray=[
          "http://a.basemaps.cartocdn.com/light_all", 
          "http://b.basemaps.cartocdn.com/light_all", 
          "http://c.basemaps.cartocdn.com/light_all", 
          "http://d.basemaps.cartocdn.com/light_all"];	

		  tilelayer = new OM.layer.OSMTileLayer("carto.light", conf_carto_maps.tileServerArray, ".png");
        // remove copyRight and add new one 
        map.removeMapDecoration(this.copyRight);
        map.addMapDecoration(copyRightCarto);
        this.copyRight = copyRightCarto;
      }
	  else if (this.Config.background == 'Carto Dark')
	  {
        var copyRightCarto = new OM.control.CopyRight(
        {anchorPosition:6,
        textValue:'&copy; <a href="http://cartodb.com/attributions" target="_blank">Carto</a> free basemaps <a href="https://carto.com/legal" target="_blank">terms</a>. &copy; <a href="http://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors', fontSize:10,fontFamily:'Helvetica Neue,Arial',fontColor:'black'});    
        
		  var conf_carto_maps={};
          conf_carto_maps.tileServerArray=[
          "http://a.basemaps.cartocdn.com/dark_all", "http://b.basemaps.cartocdn.com/dark_all", 
          "http://c.basemaps.cartocdn.com/dark_all", "http://d.basemaps.cartocdn.com/dark_all"];	
          
		  tilelayer = new OM.layer.OSMTileLayer("carto.dark", conf_carto_maps.tileServerArray, ".png");
        // remove copyRight and add new one 
        map.removeMapDecoration(this.copyRight);
        map.addMapDecoration(copyRightCarto);
        this.copyRight = copyRightCarto;
      }      
	  else
      {
		tilelayer = new OM.layer.ElocationTileLayer("oracle.maps");
        map.removeMapDecoration(this.copyRight);
      }
		
	  map.addLayer(tilelayer) ;  		
		
  
	  var pointsLayer = new OM.layer.VectorLayer("points", { def:{	type:OM.layer.VectorLayer.TYPE_LOCAL }  });   
	  var features = [];	  
	  
	  //{"long":lg, "lat":lt, "attr_val":attr_val, "metric_val":metric_val, "metric_lbl":metric_lbl}
	  for (i=0;i<darray.length; i++){
	  		var fid = i;
			var pt = darray[i];
	  		var mpoint = new OM.geometry.Point(pt.long, pt.lat,8307);
	  		var f_attr = {attributes :{}};
			
			f_attr.attributes['_TITLE_']= pt.attr_val;
			for (var k=0;k<pt.metric_val.length;k++){
				f_attr.attributes[pt.metric_lbl[k]]=pt.metric_val[k];
			}
			features.push(new OM.Feature(fid,mpoint,f_attr));   		
	  	}
	  pointsLayer.addFeatures(features);
	  
	  var imgurl = this.Config.imageurl.trim();
	  if (!imgurl || imgurl=='none' || imgurl=='')
	  {
		  var circles = [];
		  for(var i=0; i<10; i++)
		  {
			circles[i] =  new OM.style.Marker({
			  vectorDef : [{
					shape: { type:"circle", cx:4, cy:4, width:8, height:8 }, 
					style: {
						fill: conf_marker.fill, 
                        strokeWidth:conf_marker.strokeWidth,
						stroke: conf_marker.stroke
					}
				}],
			  width: 8 + i*2,
			  height:8 + i*2
			});
		  }
		  
		  var bucketStyle = new OM.style.BucketStyle(
		  {
			styles: circles,
			numClasses:10, 
			classification:'equal',  //creates equal-ranged buckets
			defaultStyle: circles[0]
		  });
			
		  var pt = darray[0];
		  var metriclabel=pt.metric_lbl[0];
		  pointsLayer.setRenderingStyle(bucketStyle, [metriclabel]);
		  
		  //pointsLayer.enableFeatureSelection(true);
          // Bug in combining pulse animation with clustering so this is disabled for now
		  var pulse = new OM.style.PulseAnimation(conf_animation);
		  pointsLayer.setHoverStyle(pulse);
          
		  /*
          // Add a cluster marker 
          var clusterMarker = new OM.style.Marker({ vectorDef: [
                        {
                            shape: {type: "circle", cx: 12, cy: 12, width: 24, height: 24},
                            style: {fill: "#ed6647", stroke: "#ffffff", strokeWidth:1}
                        }],
                        textStyle: new OM.style.Text({
                            fontFamily:"Helvetica Neue, Helvetica, Arial, sans-serif",
                            fontSize:8,
                            fill:"#333333"
          })}); 
          pointsLayer.enableClustering(true,{clusterStyle:clusterMarker,minPointCount:4, maxClusteringLevel:10, threshold:40});
		  */
	  } else {
   	    var s = new OM.style.Marker({width: 24, height: 24, src: imgurl});
		pointsLayer.setRenderingStyle(s);
	  }
	  
	  pointsLayer.setBringToTopOnMouseOver(true);
      // disable info-windows and set a tooltip customizer
      // the tooltip customizer should just return the Object or text to be displayed
      // in the tooltip
      pointsLayer.enableInfoWindow(false);
      // set Feature Hiver to true to enable the hover events
      pointsLayer.enableFeatureHover(true);
      pointsLayer.setToolTipCustomizer(toolTipCustomizer);
	  if (this.Config.zoomtotheme)	  
          pointsLayer.zoomToTheme();
	  map.addLayer(pointsLayer);
	  
      if (!this.Config.zoomtotheme)	  map.setMapZoomLevel(3) ;
	  if (this.Config.repeatbackground) map.enableMapWraparound(true);

	  var center = new OM.geometry.Point(10,48,8307); 
	  map.setMapCenter(center);
  
      // show only the +/- zoom buttons. i.e. {style:3}
	  var navigationPanelBar = new OM.control.NavigationPanelBar({style:3});
	  map.addMapDecoration(navigationPanelBar);
	  
      map.init();
      this._setIsRendered(true) ;
    };

	
	PointsMapViz.prototype._addVizSpecificPropsDialog = function(oTabbedPanelsGadgetInfo){
		this.doAddVizSpecificPropsDialog(this, oTabbedPanelsGadgetInfo);
		PointsMapViz.superClass._addVizSpecificPropsDialog.call(this, oTabbedPanelsGadgetInfo);
	};

	PointsMapViz.prototype.doAddVizSpecificPropsDialog = function (oTransientRenderingContext, oTabbedPanelsGadgetInfo) {
		  jsx.assertObject(oTransientRenderingContext, "oTransientRenderingContext");
		  jsx.assertInstanceOf(oTabbedPanelsGadgetInfo, gadgets.TabbedPanelsGadgetInfo, "oTabbedPanelsGadgetInfo", "obitech-application/gadgets.TabbedPanelsGadgetInfo");

		  var options = this.getViewConfig() || {};
		  this._fillDefaultOptions(options, null);

		  var generalPanel = gadgetdialog.forcePanelByID(oTabbedPanelsGadgetInfo, euidef.GD_PANEL_ID_GENERAL);

		  var background = [];
		  background.push(new gadgets.OptionInfo('OpenStreetMap','OpenStreetMap'));
		  background.push(new gadgets.OptionInfo('Oracle Maps','Oracle Maps'));
		  background.push(new gadgets.OptionInfo('Google Maps','Google Maps'));
		  background.push(new gadgets.OptionInfo('Mapbox Light','Mapbox Light'));
          background.push(new gadgets.OptionInfo('Carto Dark','Carto Dark'));
          background.push(new gadgets.OptionInfo('Carto Positron','Carto Positron'));          
          
                  
		  var oBackgroundGVP = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_SWITCHER, this.Config.background);
		  var oBackgroundGadgetInfo = new gadgets.TextSwitcherGadgetInfo("backgroundGadget", 'Background Map', 'Background Map', oBackgroundGVP, euidef.GD_FIELD_ORDER_GENERAL_LINE_TYPE, false, background);
		  generalPanel.addChild(oBackgroundGadgetInfo);

		  var oGadgetFactory = this.getGadgetFactory();
		  var oMapKey = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.mapkey);
          var oMapKeyGadgetInfo = oGadgetFactory.createGadgetInfo("mapKeyGadget", 'Map Key (Google|MapBox)', 'Map Key (Google|MapBox)', oMapKey);
          generalPanel.addChild(oMapKeyGadgetInfo);
                
		  var oZoomControlProps = new gadgets.CheckboxGadgetValueProperties(euidef.GadgetTypeIDs.TEXT_TOGGLE, "zoomToThemecontrol", this.Config.zoomtotheme);
          var oZoomControlCheckboxInfo = oGadgetFactory.createGadgetInfo("zoomToThemecontrol","Zoom to Points", "Zoom to Points", oZoomControlProps);
          generalPanel.addChild(oZoomControlCheckboxInfo);
		  
		  var oRepeatBgdProps = new gadgets.CheckboxGadgetValueProperties(euidef.GadgetTypeIDs.TEXT_TOGGLE, "repeatMapcontrol", this.Config.repeatbackground);
          var oRepeatBgdCheckboxInfo = oGadgetFactory.createGadgetInfo("repeatMapcontrol","Repeat Background", "Repeat Background", oRepeatBgdProps);
          generalPanel.addChild(oRepeatBgdCheckboxInfo);

		  var oImgURL = new gadgets.GadgetValueProperties(euidef.GadgetTypeIDs.TEXT_FIELD, this.Config.imageurl);
          var oImgURLGadgetInfo = oGadgetFactory.createGadgetInfo("imgURLGadget", 'Image Marker URL', 'Image Marker URL', oImgURL);
          generalPanel.addChild(oImgURLGadgetInfo);		  

		  if (PointsMapViz.superClass.doAddVizSpecificPropsDialog)
			PointsMapViz.superClass.doAddVizSpecificPropsDialog.apply(this, arguments);
	};


	PointsMapViz.prototype._handlePropChange = function (sGadgetID, oPropChange, oViewSettings, oActionContext){
	   var updateSettings = PointsMapViz.superClass._handlePropChange.call(this, sGadgetID, oPropChange, oViewSettings, oActionContext);      
		  if (updateSettings) {
			 return updateSettings; // super handled it
		  }

	   // Allow the super class an attempt to handle the changes
	   var conf = oViewSettings.getViewConfigJSON(dataviz.SettingsNS.CHART) || {};
		  
		if (sGadgetID === "backgroundGadget")
		  {
			 if (jsx.isNull(conf.background))
			 {
				conf.background = {};
			 }
			 this.setBackground(oPropChange.value);
			 updateSettings = true;
		  }
		 
		 if (sGadgetID === "imgURLGadget")
		  {
			 if (jsx.isNull(conf.imageurl))
			 {
				conf.imageurl = '';
			 }
			 this.setImageURL(oPropChange.value);
			 updateSettings = true;
		  }
		  
		 if (sGadgetID === "mapKeyGadget")
		  {
			 if (jsx.isNull(conf.mapkey))
			 {
				conf.mapkey = '';
			 }
			 this.setMapKey(oPropChange.value);
			 updateSettings = true;
		  }
		  
		  if (sGadgetID === "zoomToThemecontrol")
		  {
			 if (jsx.isNull(conf.zoomtotheme))
			 {
				conf.zoomtotheme = false;
			 }
			 this.setZoomtoTheme(oPropChange.checked);
			 updateSettings = true;
		  }
		  
		  if (sGadgetID === "repeatMapcontrol")
		  {
			 if (jsx.isNull(conf.repeatbackground))
			 {
				conf.repeatbackground = false;
			 }
			 this.setRepeatBgd(oPropChange.checked);
			 updateSettings = true;
		  }
		  return updateSettings;
	};
	
	
	PointsMapViz.prototype.resizeVisualization = function(oVizDimensions, oTransientVizContext){
	   var oTransientRenderingContext = this.createRenderingContext(oTransientVizContext);
	   this.render(oTransientRenderingContext);
	};
	
   /**
    * Factory method declared in the plugin configuration
    * @param {string} sID Component ID for the visualization
    * @param {string=} sDisplayName Component display name
    * @param {string=} sOrigin Component host identifier
    * @param {string=} sVersion 
    * @returns {module:com-company-pointsMapViz/pointsMapViz.PointsMapViz}
    * @memberof module:com-company-pointsMapViz/pointsMapViz
    */
   function createClientComponent(sID, sDisplayName, sOrigin) {
     // Argument validation done by base class
      return new PointsMapViz(sID, sDisplayName, sOrigin, PointsMapViz.VERSION);
   };

   return {
      createClientComponent : createClientComponent
   };
});
