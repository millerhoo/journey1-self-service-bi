define({
    "POINTSMAPVIZ_DISPLAY_NAME": "Custom Points Map",
    "POINTSMAPVIZ_SHORT_DISPLAY_NAME": "Custom Points Map",
    "POINTSMAPVIZ_CATEGORY":"Custom Points Map",
    "POINTSMAPVIZ_ROW":"Latitude&Longitude",
    "POINTSMAPVIZ_LABEL":"Labels",
    "POINTSMAPVIZ_METRIC":"Metrics",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."

});