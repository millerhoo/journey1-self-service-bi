
//How to get Google maps API key
//https://developers.google.com/maps/faq?csw=1#new-key
var conf_google_maps = 
{
mapTypeList:"OM.layer.GoogleTileLayer.TYPE_ROAD;OM.layer.GoogleTileLayer.TYPE_ROAD;OM.layer.GoogleTileLayer.TYPE_SATELLITE;OM.layer.GoogleTileLayer.TYPE_SHADED;OM.layer.GoogleTileLayer.TYPE_HYBRID",
mapTypeVisible:true,
libURL:"https://maps.googleapis.com/maps/api/js?",
key:""
};

var conf_marker = 
{
//	fill: "#F88997", 
//	stroke: "#FE2B4C"
	fill: "#257db3", 
	stroke: "#ffffff",
    strokeWidth:1    
};

var conf_cluster_marker = 
{
//	fill: "#F88997", 
//	stroke: "#FE2B4C"
	fill: "#ed6647", 
	stroke: "#ffffff",
    strokeWidth:1    
};

var conf_animation=
{
//	stroke: "#FE2B4C",
	stroke: "#000000",
	duration: 1,
	beginSize: 8,
	endSize: 40,
	repeatCount:3
};

// add config stuff for mapbox and other maps

var conf_mapbox_maps = 
{
    // Get MapBox key from mapbox.com/developers
    key:""
}
